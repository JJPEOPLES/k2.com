# K2 Language

K2 is an ultra-fast programming language designed to execute operations in the range of 70 nanoseconds to 9 milliseconds. It features a simple syntax for basic arithmetic operations and variable management.

## Features

- Extremely fast execution (most operations complete in under 1000 nanoseconds)
- Simple and intuitive syntax
- Support for integer arithmetic operations
- Variable assignments
- Execution time display for performance monitoring

## Installation

To compile the K2 language interpreter:

```bash
g++ -std=c++17 -O3 k2.cpp -o k2
```

## Usage

### Running a K2 program file

```bash
./k2 program.k2
```

### Executing a single expression

```bash
./k2 -e "print 100 + 200"
```

## Syntax

### Comments

Comments start with `#` and continue to the end of the line:

```
# This is a comment
```

### Variable Assignment

```
x = 10
y = 20
result = x + y
```

### Arithmetic Operations

```
# Addition
sum = a + b

# Subtraction
difference = a - b

# Multiplication
product = a * b

# Division
quotient = a / b
```

### Printing Values

```
print 42
print x
```

### Execution Time Display

Toggle the display of execution times:

```
show_exec_time on   # Enable execution time display
show_exec_time off  # Disable execution time display
```

## Examples

### Simple Calculation

```
x = 10
y = 20
sum = x + y
print sum
```

### Fibonacci Sequence

```
# Initialize variables
a = 0
b = 1

# Print initial values
print a
print b

# Calculate and print next Fibonacci number
c = a + b
print c
a = b
b = c
```

## Performance

K2 is designed for ultra-fast execution:
- Simple operations: 70-200 nanoseconds
- Variable assignments: 100-400 nanoseconds
- Print operations: 1000-2000 nanoseconds
- Complex expressions: 300-5000 nanoseconds

## Limitations

The current version of K2 has the following limitations:
- Only supports integer arithmetic
- No support for loops or conditionals (must be manually unrolled)
- No functions or procedures
- Limited error handling

## Future Enhancements

Planned features for future versions:
- Support for floating-point numbers
- Conditional statements (if/else)
- Loops (while, for)
- User-defined functions
- String manipulation
- File I/O operations