# K3 Language 
 
K3 is a modern, high-performance programming language designed for building everything from system utilities to web applications. 
 
## Installation 
 
Run `install_k3_windows.bat` as administrator to install K3. 
 
## Documentation 
 
See the `docs` directory for documentation. 
