# K3 Language 
 
K3 is a modern, high-performance programming language designed for building everything from system utilities to web applications. 
 
## Installation 
 
2. Install K3: `sudo ./install_k3_linux.sh` 
 
## Documentation 
 
See the `docs` directory for documentation. 
